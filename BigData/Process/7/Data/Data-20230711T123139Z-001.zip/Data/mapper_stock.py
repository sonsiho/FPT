import sys

for line in sys.stdin:
    part = line.split(',')    
    print (part[0], 1)
    
